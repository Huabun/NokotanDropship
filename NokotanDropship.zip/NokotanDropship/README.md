# Nokotan Dropship
The delivery rocket is playing the famous tune from the anime Shikanoko Nokonoko Koshitantan